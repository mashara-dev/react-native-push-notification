module.exports = {
    dependency: {
        platforms: {
            android: {
                "packageInstance": "new ReactNativePushNotificationPackage()"
            } 
        }
    }
};
