"use strict";

import { AppState } from "react-native";
import PushNotificationIOS from "@react-native-community/push-notification-ios";

module.exports = {
  state: AppState,
  component: PushNotificationIOS
};
